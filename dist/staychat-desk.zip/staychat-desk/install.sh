#!/usr/bin/env sh
# StayChat OS — Desk PC Edition installer (macOS / Linux)
set -e
cd "$(dirname "$0")"

if ! command -v node >/dev/null 2>&1; then
  echo "X Node.js 18 or newer is required."
  echo "  Install the LTS build from https://nodejs.org, then run this again."
  exit 1
fi
node -e 'const m=+process.versions.node.split(".")[0]; if(m<18){console.error("X Node.js 18+ required — found "+process.version);process.exit(1)}'

echo "1/3 Installing dependencies (also builds the database driver)..."
npm install --no-audit --no-fund

echo "2/3 Preparing your environment (fresh random secrets, generated locally)..."
node scripts/setup-env.js

echo "3/3 Creating your local database..."
npm run migrate

echo ""
echo "Installed. Start StayChat OS with:  npm start"
echo "Then open http://localhost:3000/app in your browser."
IP=$(hostname -I 2>/dev/null | awk '{print $1}')
echo "From another computer on your network: http://${IP:-<this-computers-ip>}:3000/app"
