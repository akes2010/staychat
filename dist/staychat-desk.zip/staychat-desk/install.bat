@echo off
rem StayChat OS - Desk PC Edition installer (Windows)
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 goto no_node
echo 1/3 Installing dependencies (also builds the database driver)...
call npm install --no-audit --no-fund
if errorlevel 1 goto failed
echo 2/3 Preparing your environment (fresh random secrets, generated locally)...
call node scripts/setup-env.js
if errorlevel 1 goto failed
echo 3/3 Creating your local database...
call npm run migrate
if errorlevel 1 goto failed
echo.
echo Installed. Start StayChat OS with:  npm start
echo Then open http://localhost:3000/app in your browser.
pause
exit /b 0

:no_node
echo X Node.js 18 or newer is required.
echo   Install the LTS build from https://nodejs.org, then run this again.
pause
exit /b 1

:failed
echo.
echo X Installation stopped - see the error above.
pause
exit /b 1
